import { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import {
  createProduct,
  getProducts,
  deleteProduct,
  updateProduct,
} from "../firebase/productService";

// Melhoria 1: Formata dígitos digitados no padrão brasileiro (R$ 1.234,56)
function formatPriceBR(value) {
  const digits = value.replace(/\D/g, "");
  if (!digits) return "";
  const cents = parseInt(digits, 10);
  const reais = (cents / 100).toFixed(2);
  return reais
    .replace(".", ",")
    .replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// Converte valor formatado em número decimal para salvar no banco
function parsePriceBR(formatted) {
  return formatted.replace(/\./g, "").replace(",", ".");
}

// Melhoria 1: Formata um número decimal para exibição em R$
function displayPrice(rawPrice) {
  const num = parseFloat(rawPrice);
  if (isNaN(num)) return rawPrice;
  return num.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function HomeScreen({ navigation, route }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [barcode, setBarcode] = useState("");
  const [products, setProducts] = useState([]);
  const [editingProductId, setEditingProductId] = useState(null);

  // Melhoria 3: Armazena o estado do formulário antes de abrir o scanner
  const pendingFormRef = useRef(null);

  async function loadProducts() {
    try {
      const productList = await getProducts();
      setProducts(productList);
    } catch (error) {
      console.error(error);
      Alert.alert("Erro", "Não foi possível carregar os produtos.");
    }
  }

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (route.params?.scannedBarcode) {
      // Melhoria 3: Restaura nome, preço e modo de edição após voltar do scanner
      if (pendingFormRef.current) {
        setName(pendingFormRef.current.name);
        setPrice(pendingFormRef.current.price);
        setEditingProductId(pendingFormRef.current.editingProductId);
        pendingFormRef.current = null;
      }
      setBarcode(String(route.params.scannedBarcode));
    }
  }, [route.params?.scannedBarcode]);

  function clearForm() {
    setName("");
    setPrice("");
    setBarcode("");
    setEditingProductId(null);
  }

  // Melhoria 1: Atualiza o preço formatado enquanto o usuário digita
  function handlePriceChange(text) {
    setPrice(formatPriceBR(text));
  }

  async function handleSaveProduct() {
    if (!name.trim() || !price.trim()) {
      Alert.alert("Atenção", "Preencha nome e preço do produto.");
      return;
    }

    const productData = {
      name: name.trim(),
      price: parsePriceBR(price.trim()), // salva como número decimal
      barcode: barcode ? String(barcode).trim() : "",
    };

    try {
      if (editingProductId) {
        await updateProduct(editingProductId, productData);
        Alert.alert("Sucesso", "Produto atualizado com sucesso!");
      } else {
        await createProduct(productData);
        Alert.alert("Sucesso", "Produto cadastrado com sucesso!");
      }
      clearForm();
      await loadProducts();
    } catch (error) {
      console.error(error);
      Alert.alert("Erro", "Não foi possível salvar o produto.");
    }
  }

  function handleEditProduct(product) {
    setName(product.name || "");
    // Melhoria 1: Converte o valor salvo para o formato BR ao editar
    const cents = Math.round(parseFloat(product.price || "0") * 100);
    setPrice(formatPriceBR(String(cents)));
    setBarcode(product.barcode || "");
    setEditingProductId(product.id);
  }

  function handleCancelEdit() {
    clearForm();
  }

  async function handleDeleteProduct(productId) {
    // Substituído window.confirm por Alert nativo (compatível com React Native)
    Alert.alert(
      "Confirmar exclusão",
      "Tem certeza que deseja excluir este produto?",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteProduct(productId);
              if (editingProductId === productId) clearForm();
              Alert.alert("Sucesso", "Produto excluído com sucesso!");
              await loadProducts();
            } catch (error) {
              console.error(error);
              Alert.alert("Erro", "Não foi possível excluir o produto.");
            }
          },
        },
      ]
    );
  }

  // Melhoria 3: Salva o formulário antes de navegar para o scanner
  function handleOpenScanner() {
    pendingFormRef.current = { name, price, editingProductId };
    navigation.navigate("BarcodeScanner");
  }

  return (
    // Melhoria 2: KeyboardAvoidingView impede que o teclado cubra os campos de entrada
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 0}
    >
      {/* Melhoria 2: Toca fora do campo fecha o teclado */}
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        {/* Melhoria 4: ScrollView garante rolagem em telas pequenas */}
        <ScrollView
          contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={{ fontSize: 24, marginTop: 40, marginBottom: 20 }}>
            Bem-vindo!
          </Text>

          <View style={{ marginBottom: 20 }}>
            <Button title="Ler código de barras" onPress={handleOpenScanner} />
          </View>

          <TextInput
            placeholder="Nome do produto"
            value={name}
            onChangeText={setName}
            returnKeyType="next"
            style={{
              borderWidth: 1,
              marginBottom: 10,
              padding: 10,
              borderRadius: 5,
            }}
          />

          {/* Melhoria 1: Campo de preço com formatação brasileira em tempo real */}
          <TextInput
            placeholder="Preço (ex: 9,99)"
            value={price}
            onChangeText={handlePriceChange}
            keyboardType="numeric"
            returnKeyType="next"
            style={{
              borderWidth: 1,
              marginBottom: 10,
              padding: 10,
              borderRadius: 5,
            }}
          />

          <TextInput
            placeholder="Código de barras"
            value={barcode}
            onChangeText={setBarcode}
            returnKeyType="done"
            onSubmitEditing={Keyboard.dismiss}
            style={{
              borderWidth: 1,
              marginBottom: 20,
              padding: 10,
              borderRadius: 5,
            }}
          />

          <Button
            title={editingProductId ? "Atualizar produto" : "Cadastrar produto"}
            onPress={handleSaveProduct}
          />

          {editingProductId && (
            <View style={{ marginTop: 10 }}>
              <Button title="Cancelar edição" onPress={handleCancelEdit} />
            </View>
          )}

          <Text style={{ fontSize: 20, marginTop: 30, marginBottom: 10 }}>
            Produtos cadastrados
          </Text>

          {products.length === 0 ? (
            <Text>Nenhum produto cadastrado.</Text>
          ) : (
            products.map((item) => (
              <View
                key={item.id}
                style={{
                  borderWidth: 1,
                  borderRadius: 5,
                  padding: 10,
                  marginBottom: 10,
                }}
              >
                <Text>Nome: {item.name}</Text>
                {/* Melhoria 1: Exibe o preço formatado em R$ */}
                <Text>Preço: {displayPrice(item.price)}</Text>
                <Text>
                  Código de barras: {item.barcode || "Não informado"}
                </Text>

                <View style={{ marginTop: 10 }}>
                  <Button
                    title="Editar"
                    onPress={() => handleEditProduct(item)}
                  />
                </View>

                <View style={{ marginTop: 10 }}>
                  <Button
                    title="Excluir"
                    onPress={() => handleDeleteProduct(item.id)}
                  />
                </View>
              </View>
            ))
          )}

          <View style={{ marginTop: 20 }}>
            <Button title="Sair" onPress={() => navigation.navigate("Login")} />
          </View>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}
